package conn.bean;

public class Member {
	String id;
	String pw;
	String name;
	String email;
	String sex;
	String age;
	String height;
	String weight;
	String bio[];
	String exercise[];
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public String[] getBio() {
		return bio;
	}
	public void setBio(String[] bio) {
		this.bio = bio;
	}
	public String[] getExercise() {
		return exercise;
	}
	public void setExercise(String[] exercise) {
		this.exercise = exercise;
	}
}
